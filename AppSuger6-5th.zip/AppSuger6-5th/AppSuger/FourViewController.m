//
//  FourViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/3/5.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "FourViewController.h"

@interface FourViewController ()

@end

@implementation FourViewController
- (NSString *) reruturnUrlStr {
    
    return [NSString stringWithFormat:CATEGORY_URL,@"10"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
