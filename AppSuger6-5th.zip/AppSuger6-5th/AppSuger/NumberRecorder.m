//
//  NumberRecorder.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "NumberRecorder.h"
#import "Define.h"

@implementation NumberRecorder

+ (void) recordAppLoadNum {

    NSInteger num = [[NSUserDefaults standardUserDefaults] integerForKey:appLoadNum];
    if (num == 0 ) {
        //说明是第一次打开应用程序
    }else {
        //不是第一次打开
    }
    num++;
    NSLog(@"第几次打开应用程序 %ld",num);
    [[NSUserDefaults standardUserDefaults] setInteger:num forKey:appLoadNum];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//是否是第一次打开软件
+ (BOOL) isFirstLoadApp {

    NSInteger num = [[NSUserDefaults standardUserDefaults] integerForKey:appLoadNum];
    if (num == 1 ) {
        return YES ;
    } else
        
    return NO;
}

@end
