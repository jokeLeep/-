//
//  DetailListTableViewCell.m
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "DetailListTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation DetailListTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)configDataWithModel:(DetailListModel *)model indexPath:(NSIndexPath *)indexPath {

    
    
    //商品的编号
    NSString * imageName = [NSString stringWithFormat:@"ind%.2d",model.number.intValue + 1 ] ;
   self.numImage = [self.numImage  initWithImage:[UIImage imageNamed:imageName]];
    
    self.titleLabel.text = model.title;
    self.detailLabel.text = model.desc;
    //商品价格
    self.priceLabel.text = [NSString stringWithFormat:@"RMB:%@",model.price];
    [self.titleLabel setFont:[UIFont fontWithName:@"American Typewriter" size:15]];
    [self.detailLabel setFont:[UIFont fontWithName:@"American Typewriter" size:13]];
    
    
    if (model.pic.count == 0 ) {
        return ;
    }
    
    //存储图片的字典
    NSDictionary * picDic = model.pic[0];
    //商品的展示图片
    
        [self.PicImage sd_setImageWithURL:[NSURL URLWithString:picDic[@"pic"]] placeholderImage:[UIImage imageNamed:@"placehoder"]];
        [self.PicImage.image imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
