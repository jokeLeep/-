//
//  DetailViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "DetailViewController.h"
#import "DetailListModel.h"
#import "TopModel.h"
#import "DetailListTableViewCell.h"
#import "DetailTopTableViewCell.h"
#import "AFNetworking.h"
#import "Define.h"
#import "UIImageView+WebCache.h"

#import "TaoBaoLinkViewController.h"


#import "MyFMDBInfo.h"

@interface DetailViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    // 判断是否已经添加到收藏栏中
    BOOL  _isExist;
    //
    MyFMDBInfo * _myFMDBInfo;
}
@property (nonatomic, strong) UIImageView * headerImageView ;
//异步请求数据
@property (nonatomic, strong) AFHTTPRequestOperationManager * manager ;
//请求网络数据的接口
@property (nonatomic, copy) NSString * requestUrl ;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//创建上面的主页图片 添加下拉 变大效果
    
    
    self.title = @"详情";
    //收藏功能
    [self createMyLove];
    
    //创建表格视图
    [self createTableView];
    [self layoutHeardImageView];
    [self fristDownLoadWithURL:self.mainCell];
    
//    self.tableView.estimatedRowHeight = 468.0 ;
}


- (void) createMyLove {

    if (self.model != nil) {
        UIBarButtonItem * rightBtn = [[UIBarButtonItem alloc] initWithTitle:nil style:UIBarButtonItemStylePlain target:self action:@selector(addCollentionIntoMyDataBase)];
        // 判断数据中是否已经存在
        _myFMDBInfo = [[MyFMDBInfo alloc] init];
        [_myFMDBInfo open];
        _isExist = [_myFMDBInfo isExistedWithCellId:self.mainCell andRecordType:@"myLove"];
        if (_isExist) {
            UIImage *image = [[UIImage imageNamed:@"stared"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            [rightBtn setImage:image];
            self.navigationItem.rightBarButtonItem = rightBtn;
        } else {
            UIImage *image = [[UIImage imageNamed:@"star"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            [rightBtn setImage:image];
            self.navigationItem.rightBarButtonItem = rightBtn;
        }
    }

}
#pragma mark - 收藏的相关方法 -
- (BOOL)addCollentionIntoMyDataBase {
    
    if (_isExist == NO) {
        UIImage *image = [[UIImage imageNamed:@"stared"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        [self.navigationItem.rightBarButtonItem setImage:image];
        [_myFMDBInfo insertCollectionWithModel:self.model andRecordType:@"myLove"];
        
    } else {
        UIImage *image = [[UIImage imageNamed:@"star"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        [self.navigationItem.rightBarButtonItem setImage:image];
        [_myFMDBInfo deleteOneCollentionWithCellId:self.mainCell andRecordType:@"myLove"];
        // 发送一个广播，让收藏界面刷新
        [[NSNotificationCenter defaultCenter] postNotificationName:@"refresh" object:nil];
        return  _isExist = NO;
    }
    // 发送一个广播，让收藏界面刷新
    [[NSNotificationCenter defaultCenter] postNotificationName:@"refresh" object:nil];
    return  _isExist = YES;
}

- (void) layoutHeardImageView {

    UIView * hearderBackView = [[UIView alloc]initWithFrame: CGRectMake(0, 0, self.view.frame.size.width, 200)];
    hearderBackView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = hearderBackView ;
    
    self.headerImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 200)];
    self.headerImageView.backgroundColor = [UIColor whiteColor];

    self.headerImageView.image = [[UIImage imageNamed:@"placehoder.png"]imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
    
    [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:self.model.pic] placeholderImage:[UIImage imageNamed:@"placehoder"]];

    self.headerImageView.contentMode = UIViewContentModeScaleAspectFill ;
    self.headerImageView.clipsToBounds = YES ;
    [hearderBackView addSubview:self.headerImageView];
}
- (void) scrollViewDidScroll:(UIScrollView *)scrollView {

    CGFloat width = self.view.frame.size.width ;//取到图片的宽度
    CGFloat yOffset = scrollView.contentOffset.y ; //偏移量
    
    if (yOffset < 0 ) {
    
        CGFloat totalOffset = 200 + ABS(yOffset);
        CGFloat f = totalOffset / 200 ; //缩放系数
        self.headerImageView.frame = CGRectMake(-(width * f - width) / 2,-(width * f - width) / 2 , width * f,  totalOffset);
    }
}


#pragma mark - 创建表格视图
- (void) createTableView {
    self.topArray = [[NSMutableArray alloc] init];
    self.dataArray = [[NSMutableArray alloc] init];
    if ([self.type isEqualToString:@"mainPage"]){
    
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height - 64) style:UITableViewStylePlain];
    } else {
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height) style:UITableViewStylePlain];
    }
    [self.view addSubview: self.tableView];
    self.tableView.delegate = self ;
    self.tableView.dataSource = self ;
    //注册列表表格
    [self.tableView registerNib:[UINib nibWithNibName:@"DetailListTableViewCell" bundle:nil] forCellReuseIdentifier:@"DetailListTableViewCell"];
    self.tableView.separatorStyle = UITableViewCellAccessoryNone ;
    self.tableView.showsVerticalScrollIndicator = NO ;
    //注册top表格
    [self.tableView registerNib:[UINib nibWithNibName:@"DetailTopTableViewCell" bundle:nil] forCellReuseIdentifier:@"DetailTopTableViewCell"];
}

# pragma mark - 下载数据

- (void) fristDownLoadWithURL:(NSString *)updeateTime {
  
    __weak typeof (self) weakSelf = self ;
    NSString * url = [NSString stringWithFormat:DETAIL_URL,self.mainCell];
    //初始化manager
    self.manager = [AFHTTPRequestOperationManager manager];
    //设置服务器响应格式
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    //利用第三方库AFNetWorking 下载网络数据 GET方法
    [weakSelf.manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"%@",[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding]);
       //把json数据转化为字典
        NSDictionary * allDataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        //找到字典中键值是data的数据，得到的结果是个字典
        NSDictionary * dataDic = allDataDic[@"data"];
        //取到产品的数组
        NSArray * productArray = dataDic[@"product"];
        //头部模型的数据
        TopModel * topModel = [[TopModel alloc] initWithDictionary:dataDic error:nil];
//        NSLog(@"topModel%@" ,topModel);
        [self.dataArray addObject:topModel];
        //加入到模型中
        for (NSDictionary * listDic in productArray) {
            DetailListModel * listModel = [[DetailListModel alloc] initWithDictionary:listDic error:nil];
            [weakSelf.dataArray addObject:listModel];
        }
        [weakSelf.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"下载失败 : %@",error);
    }];

}

#pragma mark - UITableView的代理方法
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {

    return 1 ;
}
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return  self.dataArray.count;
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.row == 0 ) {
        return 182 ;
    }
    return 460 ;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.row == 0) {
        DetailTopTableViewCell * topcell = [tableView dequeueReusableCellWithIdentifier:@"DetailTopTableViewCell"];
        TopModel * model = self.dataArray[0];
        NSLog(@"%@",model);
        [topcell congfigDataWithTopModel:model];
        
        topcell.selectionStyle = UITableViewCellSelectionStyleNone ;
        return topcell  ;
    }else {
    
        DetailListTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DetailListTableViewCell"];
        DetailListModel * model = self.dataArray[indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone ;
        [cell configDataWithModel:model indexPath:indexPath];
        return cell ;
    }

}

//列表的点击 传递
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.row != 0){
    
        DetailListModel * model = self.dataArray[indexPath.row];
        TaoBaoLinkViewController * taoBaoLink = [[TaoBaoLinkViewController alloc]init];
        taoBaoLink.type = self.type ;
        taoBaoLink.taoBaoLinkURl = model.url ;
        [self.navigationController pushViewController:taoBaoLink animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
