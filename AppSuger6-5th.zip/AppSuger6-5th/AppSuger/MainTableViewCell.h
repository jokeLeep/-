//
//  MainTableViewCell.h
//  AppSuger
//
//  Created by qianfeng on 16/2/26.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainPageModel.h"

@interface MainTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *loveNumLabel;
@property (weak, nonatomic) IBOutlet UIImageView *picImage;
@property (weak, nonatomic) IBOutlet UIImageView *buttonImage;
@property (weak, nonatomic) IBOutlet UIImageView *heartImage;

// 在表格中展示数据
- (void) showDataWithModel:(MainPageModel *) mainModel andIndexPath:(NSIndexPath *)indexPath ;

@end
