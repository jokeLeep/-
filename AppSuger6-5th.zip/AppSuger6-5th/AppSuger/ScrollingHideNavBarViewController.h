//
//  ScrollingHideNavBarViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>

//屏幕高度
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#pragma mark - 判断是否ios7
#define IOS7 ([[[UIDevice currentDevice]systemVersion] floatValue] >= 7.0)

@interface ScrollingHideNavBarViewController : UIViewController

@property (nonatomic, weak) UIView * scrollView ;
@property (assign,nonatomic) BOOL isHidden ;

- (void) followRollingScrollerView:(UIView *) scrollView;
- (void) touchNavigationBarBack ;

@end
