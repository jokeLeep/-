//
//  ThirdTurnViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/3/1.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "MainPageViewController.h"

@interface ThirdTurnViewController : MainPageViewController

@property (nonatomic, copy) NSString * listUrl ;
@property (nonatomic, copy) NSString * type ;
@property (nonatomic, copy) NSString * mainCell ;

@end
