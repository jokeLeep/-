//
//  ClassSearchViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassSearchViewController : UIViewController

@end
