//
//  TaoBaoLinkViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/29.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "MainPageViewController.h"

@interface TaoBaoLinkViewController : MainPageViewController

//链接网址
@property (nonatomic, copy) NSString * taoBaoLinkURl ;

@property (nonatomic, copy) NSString * type ;

@end
