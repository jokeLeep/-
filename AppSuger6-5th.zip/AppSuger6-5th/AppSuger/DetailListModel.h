//
//  DetailListModel.h
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "JSONModel.h"

@interface DetailListModel : JSONModel

@property (nonatomic,copy)NSString <Optional>*number;
@property (nonatomic,copy)NSString <Optional>*desc;
@property (nonatomic,copy)NSString <Optional>*price;
@property (nonatomic,copy)NSString <Optional>*url;
@property (nonatomic,copy)NSString <Optional>*title;
@property (nonatomic,copy)NSArray <Optional>*pic;

@property (nonatomic,copy)NSString <Optional>*id;
@property (nonatomic,copy)NSString <Optional>*likes;
@property (nonatomic,copy)NSString <Optional>*islike;
@property (nonatomic,copy)NSString <Optional>*comments;
@property (nonatomic,copy)NSString <Optional>*iscomments;
@property (nonatomic,copy)NSString <Optional>*category;
@property (nonatomic,copy)NSString <Optional>*topic_id;
@property (nonatomic,copy)NSString <Optional>*item_id;
@property (nonatomic,copy)NSString <Optional>*platform;
@property (nonatomic,copy)NSString <Optional>*share_url;

@end
