//
//  DetailViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainPageViewController.h"
#import "MainPageModel.h"
#import "MainPageViewController.h"

@interface DetailViewController : MainPageViewController

//确定点击了某行
@property (nonatomic, copy) NSString *mainCell ;
// 用来判断是哪个页面推出的此页面
@property (nonatomic,copy) NSString * type;
// 确定点击的数据模型
@property (nonatomic,strong) MainPageModel * model;
// 展示详情的表格
@property (nonatomic,strong) UITableView * tableView;
// 用来存储数据的容器
@property (nonatomic,strong) NSMutableArray * dataArray;
// 顶部
@property (nonatomic,strong) NSMutableArray * topArray;
// 顶部的表格
@property (nonatomic,strong) UITableView * topView;


@end
