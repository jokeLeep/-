//
//  MyFMDBInfo.h
//  AppSuger
//
//  Created by qianfeng on 16/3/7.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MainPageModel.h"
#import "FMDB.h"

@interface MyFMDBInfo : NSObject
{
    //记录是否打开成功
    BOOL _isOpenSuccess ;
    //创建数据库管理对象
    FMDatabase * _dataBase ;
}

//打开成功
- (BOOL) open ;
/**
 *  插入 数据 表示新加入一条收藏
 *
 *  @param model 插入的数据模型
 *  @param type  参数的标记
 *  return 状态
 */
- (void)insertCollectionWithModel:(MainPageModel *)model andRecordType:(NSString *)type;

//删除一条收藏记录 根据其cellId来删除
- (void)deleteOneCollentionWithCellId:(NSString *)cellId andRecordType:(NSString *)type;
//判断正在浏览的这一项是否已经被收藏了
- (BOOL)isExistedWithCellId:(NSString *)cellId andRecordType:(NSString *)type;
//获取表中的信息
- (NSArray *)getdataInfoWithRecordType:(NSString *)type;

@end
