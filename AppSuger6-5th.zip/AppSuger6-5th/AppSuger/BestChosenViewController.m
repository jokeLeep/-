//
//  BestChosenViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "BestChosenViewController.h"
#import "DBSphereView.h"
#import "Define.h"
#import "ThirdTurnViewController.h"

@interface BestChosenViewController ()

@property (nonatomic, strong) DBSphereView * sphereView ;

@end

@implementation BestChosenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createSphereView];
    self.view.backgroundColor = [UIColor whiteColor];
    
    //子类重写父类的方法
    [self createViews:@"精品分类"];

 
}
- (void) createSphereView {

    self.sphereView = [[DBSphereView alloc]initWithFrame:CGRectMake(0, SCREEN_SIZE.height / 4 - 64, SCREEN_SIZE.width , SCREEN_SIZE.height / 2)];
    NSArray * array = @[@"精选",@"美妆",@"数码",@"杂货",@"男票",@"女票",@"包包",@"鞋控",@"配饰",@"办公",@"运动",@"零食",@"图书",@"电器",@"彩妆",@"精选",@"美妆",@"数码",@"杂货",@"男票",@"女票",@"包包",@"鞋控",@"配饰",@"办公",@"运动",@"零食",@"图书",@"电器",@"彩妆",@"精选",@"美妆",@"数码",@"杂货",@"男票",@"女票",@"包包",@"鞋控",@"配饰",@"办公",@"运动",@"零食",@"图书",@"电器",@"彩妆"];
    NSMutableArray * muArr = [[NSMutableArray alloc]init];
    for (int i = 0 ; i < array.count; i ++) {
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeSystem];
        [btn setTitle:array[i] forState:(UIControlStateNormal)];
        btn.frame = CGRectMake(0, 0, 100, 50);
//        [btn setBackgroundImage:[UIImage imageNamed:@"buttom" ] forState:UIControlStateNormal];
//        btn.alpha = 0.05 ;
//        [btn setTintColor:[UIColor blueColor]];
        
        UIColor *color = [UIColor colorWithRed:arc4random() % 256 / 255.0 green:arc4random() % 256 / 255.0 blue:arc4random() % 256 / 255.0 alpha:1];
        [btn setTitleColor:color forState:UIControlStateNormal];
        
        btn.titleLabel.font = [UIFont systemFontOfSize:25];
//        btn.clipsToBounds = YES ;
//        btn.layer.cornerRadius = 10 ;
        
        [btn addTarget:self action:@selector(buttonPressed:) forControlEvents:(UIControlEventTouchUpInside)];
        [muArr addObject:btn];
        [self.sphereView addSubview:btn];
    }
    [self.sphereView setCloudTags:muArr];
    self.sphereView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.sphereView];
}
- (void)buttonPressed:(UIButton *)btn
{
    [self.sphereView timerStop];
//    NSLog(@"btn %@",btn.titleLabel.text);
    [UIView animateWithDuration:0.3 animations:^{
        btn.transform = CGAffineTransformMakeScale(2., 2.);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3 animations:^{
            btn.transform = CGAffineTransformMakeScale(1., 1.);
        } completion:^(BOOL finished) {
            
            [self cleckBtn:btn];
            [self.sphereView timerStart];
        }];
    }];
}

- (void) cleckBtn:(UIButton *) btn {
   
   NSString * btnNum = [self findURLFromSource:btn.titleLabel.text];
    ThirdTurnViewController * ttVc = [[ThirdTurnViewController alloc]init];
    NSString * url = [NSString stringWithFormat:CATEGORY_URL,btnNum];
    ttVc.listUrl = url ;
    ttVc.type = btnNum ;
    ttVc.title = btn.titleLabel.text ;
    [self.navigationController pushViewController:ttVc animated:YES];
}
//拼接网址
- (NSString *) findURLFromSource: (NSString *)buttonName {

    NSDictionary * urlSource = @{@"精选":@"0",@"美妆":@"1",@"数码":@"2",@"杂货":@"3",@"男票":@"4",@"女票":@"5",@"包包":@"6",@"鞋控":@"7",@"配饰":@"8",@"办公":@"9",@"运动":@"10",@"零食":@"11",@"图书":@"12",@"电器":@"13",@"彩妆":@"14"};
    NSString *  num = urlSource[buttonName];
    return num ;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
