//
//  TopicViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "TopicViewController.h"
#import "ThridBaseViewController.h"
#import "ThirdTableView.h"

#import "MainPageModel.h"
#import "MainTableViewCell.h"
#import "AFNetworking.h"

#import "Define.h"

#import "DetailViewController.h"

@interface TopicViewController ()<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) UIScrollView * titleScrollView ;
@property (nonatomic, strong) UIScrollView * contentScrollView ;
@property (nonatomic, assign) NSInteger tableViewCount ;
@property (nonatomic, assign) NSInteger titleBtnTag ;


@property (nonatomic, strong) NSMutableArray * bannerImageArray ;
@property (nonatomic, strong) NSMutableArray * dataArray ;
@property (nonatomic, strong) AFHTTPRequestOperationManager * manager ;
@property (nonatomic, strong) UITableView * tabelView ;

@end

@implementation TopicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    //自动调节 滚动型插图
    self.automaticallyAdjustsScrollViewInsets = NO ;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self createTitleScrollView];
    
    [self createContentScrollView];
    
    [self createTitleBtn];
    _dataArray = [[NSMutableArray alloc]init];
   
     [self createViews:@"概述"];
    
}

- (void) createTitleScrollView {

    _titleScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, 40)];
    _titleScrollView.delegate = self ;
    
    _titleScrollView.showsVerticalScrollIndicator = NO ;
    _titleScrollView.showsHorizontalScrollIndicator = NO ;
    
    [self.view addSubview:_titleScrollView];
}

- (void) createContentScrollView {
 
    _contentScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 40, SCREEN_SIZE.width, SCREEN_SIZE.height - 108)];
    _contentScrollView.delegate = self ;
    
    _contentScrollView.pagingEnabled = YES ;
    _contentScrollView.directionalLockEnabled = YES ;
    _contentScrollView.bounces = NO ;
    _contentScrollView.showsHorizontalScrollIndicator = YES ;
    _contentScrollView.showsVerticalScrollIndicator = YES ;
    
    [self.view addSubview:_contentScrollView];

}

- (void) createTitleBtn {

    NSArray * titleName = @[@"I",@"II",@"III",@"IV",@"V",@"VI",@"VII"];
    NSArray * classArray = @[@"OneViewController",@"TwoViewController",@"ThreeViewController",@"FourViewController",@"FiveViewController",@"SixViewController",@"SevenViewController"];
    for (int i = 0 ; i < titleName.count; i++) {
        [self addTitleBtnToTitileScrollWithTitle:titleName[i]];
        [self addTableViewToContentScrollWithClassNameL:classArray[i]];
    }
    
    _titleScrollView.contentSize = CGSizeMake(self.titleScrollView.subviews.count * 73 , 40);
    _contentScrollView.contentSize = CGSizeMake(self.contentScrollView.subviews.count * SCREEN_SIZE.width, SCREEN_SIZE.height - 104);
}
- (void) addTitleBtnToTitileScrollWithTitle:(NSString *)title {
 
    self.tableViewCount ++ ;
    UIButton * titleButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [titleButton setTitle:title forState:(UIControlStateNormal)];
    [titleButton setTitleColor:[UIColor grayColor] forState:(UIControlStateNormal)];
    titleButton.titleLabel.font = [UIFont systemFontOfSize:15];
    titleButton.frame = CGRectMake(self.titleScrollView.subviews.count * 73.0 , 0, 70, 40);
    _titleBtnTag++;
    titleButton.tag = _titleBtnTag ;
    if (titleButton.tag == 1 ) {
        [self changeTitleColor:titleButton];
    }
    [titleButton addTarget:self action:@selector(titleBtnPressed:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.titleScrollView addSubview:titleButton];
    
}
- (void) addTableViewToContentScrollWithClassNameL:(NSString *) urlStr {

     Class className = NSClassFromString(urlStr);
    ThirdTableView * tableView = [[className alloc]initWithFrame:CGRectMake(self.contentScrollView.subviews.count * SCREEN_SIZE.width,0 ,SCREEN_SIZE.width, SCREEN_SIZE.height - 40 ) style:(UITableViewStylePlain)];
    
//    tableView.backgroundColor = [UIColor colorWithRed:arc4random()%255/256.0 green:arc4random()%255/256.0 blue:arc4random()%255/256.0 alpha:1.0];
    
     tableView.tag = self.contentScrollView.subviews.count + 100 ;
    if (tableView.tag == 100) {
        
        [tableView reloadData];
    }
    
     [tableView registerNib:[UINib nibWithNibName:@"MainTableViewCell" bundle:nil] forCellReuseIdentifier:@"MainTableViewCell"];
    tableView.dataSource =self ;
    tableView.delegate = self ;
    
    _tabelView = tableView ;
    [_contentScrollView addSubview:tableView];
}

-(void) titleBtnPressed:(UIButton *) btn {

    _contentScrollView.contentOffset = CGPointMake(SCREEN_SIZE.width * (btn.tag - 1), 0);
    [self changeTitleColor:btn];

}

- (void) changeTitleColor:(UIButton *)btn {
    
    for (int i = 0 ; i  < self.titleScrollView.subviews.count; i++) {
        UIButton * btn = self.titleScrollView.subviews[i];
        if ([NSStringFromClass([btn class]) isEqualToString:@"UIButton"]){
            
            [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
            btn.titleLabel.font = [UIFont systemFontOfSize:16];
        }
    }
    [btn setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
    btn.titleLabel.font = [UIFont systemFontOfSize:19];
}

- (void) scrollViewDidScroll:(UIScrollView *)scrollView {

    if (scrollView == _contentScrollView) {
        CGFloat widthOffset = scrollView.contentOffset.x ;
        if (widthOffset < 0 ){
            widthOffset = 0 ;
        }
        NSInteger tag = widthOffset / SCREEN_SIZE.width + 1 ;
        UIButton *btn = (UIButton *)[self.view viewWithTag:tag];
        
        ThirdTableView *tableView = [self.view viewWithTag:100 + tag - 1];
        [self downLoadDataWithURL:tableView.selfUrl];
//
         [tableView reloadData];
        [self changeTitleColor:btn];
        if (widthOffset > _titleBtnTag / 2 * SCREEN_SIZE.width) {
            [UIView animateWithDuration:0.5 animations:^{
                _titleScrollView.contentOffset = CGPointMake(80, 0);
            }];
            
        } else {
            [UIView animateWithDuration:0.5 animations:^{
                _titleScrollView.contentOffset = CGPointMake(0, 0);
            }];
        }
       
    } else if (scrollView == _titleScrollView) {

    }
    
    
}

#pragma mark - UITableView 代理方法
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1 ;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataArray.count;
    
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 200 ;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell" forIndexPath:indexPath ];
    if (cell) {
        if (!self.dataArray[indexPath.row]) {
            return nil;
        }
        MainPageModel * model = self.dataArray[indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone ;
        [cell showDataWithModel:model andIndexPath:indexPath];
    }
       return cell;
}

- (void) downLoadDataWithURL:(NSString *) url {

    
    //初始化manager
    self.manager = [AFHTTPRequestOperationManager manager];
    //设置服务器响应的格式
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    __weak typeof (self) weakSelf = self ;
    
    [weakSelf.manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.dataArray removeAllObjects];
        //把json数据转化为字典
        NSDictionary * AllDataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        //找到字典中键值是data的数据，得到的结果是个字典
        NSDictionary * dataDic = AllDataDic[@"data"];
        //找到商品数组
        NSArray * topicArray = dataDic[@"topic"];
        //加入到模型中
        for (NSDictionary * oneDic in topicArray) {
            
            MainPageModel * oneModel = [[MainPageModel alloc] initWithDictionary:oneDic error:nil];
            [self.dataArray addObject:oneModel];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
    
}


- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    MainPageModel * model =  self.dataArray[indexPath.row];
    DetailViewController * devc = [[DetailViewController alloc]init];
    devc.mainCell = model.id ;
    //这一句代码是为了解决列表界面的frame的问题
    devc.type = @"mainPage";
    //为以后的收藏 做准备
    devc.model = model ;
    [self.tabelView deselectRowAtIndexPath:indexPath animated:YES];
    //当进入到下一个界面的时候 隐藏地步的toolbar
    devc .hidesBottomBarWhenPushed = YES ;
    [self.navigationController pushViewController:devc animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
