//
//  ThirdTableView.m
//  AppSuger
//
//  Created by qianfeng on 16/3/4.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "ThirdTableView.h"
#import "Define.h"
#import "AFNetworking.h"
#import "MainPageModel.h"
#import "MainTableViewCell.h"
#import "DetailViewController.h"


@interface ThirdTableView()

@property (nonatomic, strong) NSMutableArray * bannerImageArray ;
@property (nonatomic, strong) NSMutableArray * dataArray ;

@property (nonatomic, strong) AFHTTPRequestOperationManager * manager ;

@end

@implementation ThirdTableView



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (NSString *) reruturnUrlStr {

    
    return nil ;
}

//- (void) downLoadDataWithURL:(NSString *) url {
//    
//    //初始化manager
//    self.manager = [AFHTTPRequestOperationManager manager];
//    //设置服务器响应的格式
//    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    
//    __weak typeof (self) weakSelf = self ;
//    
//    [weakSelf.manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        
////        NSLog(@"%@",responseObject);
//        //把json数据转化为字典
//        NSDictionary * AllDataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//        //找到字典中键值是data的数据，得到的结果是个字典
//        NSDictionary * dataDic = AllDataDic[@"data"];
//        //找到商品数组
//        NSArray * topicArray = dataDic[@"topic"];
//        //加入到模型中
//        for (NSDictionary * oneDic in topicArray) {
//            
//            MainPageModel * oneModel = [[MainPageModel alloc] initWithDictionary:oneDic error:nil];
//            
//            [self.dataArray addObject:oneModel];
//            
//        }
//        [_tableView reloadData];
//        
//        
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        
//    }];
//    
//}


- (instancetype) initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    
    if (self = [super initWithFrame:frame style:style]) {
        
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height) style:(UITableViewStylePlain)];
        _dataArray = [NSMutableArray array];
        _bannerImageArray = [NSMutableArray array];
//        
//        self.tableView.delegate = self ;
//        self.tableView.dataSource = self ;
        
         self.estimatedRowHeight = 44;
        [self.tableView registerNib:[UINib nibWithNibName:@"MainTableViewCell" bundle:nil] forCellReuseIdentifier:@"MainTableViewCell"];
        
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
        self.tableView.showsVerticalScrollIndicator = NO ;
        
        self.tableView.tableFooterView = [[UIView alloc]init];
        
        NSString * str = [self reruturnUrlStr];
        
        self.selfUrl = str ;
//        [self downLoadDataWithURL:str];
        
    }

    return self ;
    
}
//#pragma mark - UITableView 代理方法
//- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
//    
//    return 1 ;
//}
//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
// 
//    return 5;
//    
//}
//- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    return 200 ;
//}

//- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell" forIndexPath:indexPath];
//    MainPageModel * model = self.dataSource[indexPath.row];
//    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
//    
//    [cell showDataWithModel:model andIndexPath:indexPath];
//    
//    return cell;
//}


@end
