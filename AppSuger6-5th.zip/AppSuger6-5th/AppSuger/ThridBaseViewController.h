//
//  ThridBaseViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/3/1.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "MainPageViewController.h"

@interface ThridBaseViewController : MainPageViewController

//@property (nonatomic, copy) NSString * selfUrl ;

@end
