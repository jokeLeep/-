//
//  TaoBaoLinkViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/29.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "TaoBaoLinkViewController.h"
#import "Define.h"

@interface TaoBaoLinkViewController ()
{
    UIWebView * _webView ;
}
@end

@implementation TaoBaoLinkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"淘宝" ;
    [self createWebView];
}

- (void) createWebView {

    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:198/255.0f green:79/255.0f blue:75/255.0f alpha:1.0];
    NSDictionary * attributeDic = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:19],NSFontAttributeName, [UIColor whiteColor],NSForegroundColorAttributeName,nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributeDic];
    
    if ([self.type isEqualToString:@"mainPage"]) {
    
        _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height - 64)];
    }else {
    
        _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height)];
    }
    [self.view addSubview:_webView];
    NSURL * url = [NSURL URLWithString:self.taoBaoLinkURl];
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
