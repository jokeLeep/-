//
//  MainPageViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScrollingHideNavBarViewController.h"

@interface MainPageViewController : ScrollingHideNavBarViewController

//定制界面
- (void) createViews:(NSString *)title ;

@end
