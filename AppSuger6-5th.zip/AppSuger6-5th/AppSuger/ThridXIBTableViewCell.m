//
//  ThridXIBTableViewCell.m
//  AppSuger
//
//  Created by qianfeng on 16/3/3.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "ThridXIBTableViewCell.h"

@implementation ThridXIBTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
