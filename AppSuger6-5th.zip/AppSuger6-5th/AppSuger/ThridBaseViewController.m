//
//  ThridBaseViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/3/1.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "ThridBaseViewController.h"
#import "Define.h"
#import "AFNetworking.h"
#import "MainPageModel.h"
#import "MainTableViewCell.h"
#import "DetailViewController.h"


@interface ThridBaseViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray * dataSource ;

@property (nonatomic, strong) NSMutableArray * bannerImageArray ;

@property (nonatomic, strong) UITableView * tableView ;

@property (nonatomic, strong) AFHTTPRequestOperationManager * manager ;

@end

@implementation ThridBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    NSLog(@"self.selfUrl %@",self.selfUrl);
    
//    [self picTogeterURL];
//    [self createTableView];
    
}

/*- (void) createTest {
 
 ThridBaseViewController *oneViewController = [[ThridBaseViewController alloc] init];
 oneViewController.title = @"精选";
 oneViewController.selfUrl = @"0" ;
 oneViewController.view.backgroundColor = [UIColor brownColor];
 
 ThridBaseViewController *twoViewController = [[ThridBaseViewController alloc] init];
 twoViewController.title = @"数码控";
 twoViewController.selfUrl = @"2" ;
 twoViewController.view.backgroundColor = [UIColor purpleColor];
 
 ThridBaseViewController *threeViewController = [[ThridBaseViewController alloc] init];
 threeViewController.title = @"小男友";
 threeViewController.selfUrl = @"4" ;
 //    threeViewController.view.backgroundColor = [UIColor orangeColor];
 
 
 ThridBaseViewController *fourViewController = [[ThridBaseViewController alloc] init];
 fourViewController.title = @"鞋控";
 fourViewController.selfUrl = @"7" ;
 //    fourViewController.view.backgroundColor = [UIColor magentaColor];
 
 ThridBaseViewController *fiveViewController = [[ThridBaseViewController alloc] init];
 fiveViewController.title = @"配饰";
 fiveViewController.selfUrl = @"8" ;
 //    fiveViewController.view.backgroundColor = [UIColor yellowColor];
 
 ThridBaseViewController *sixViewController = [[ThridBaseViewController alloc] init];
 sixViewController.title = @"运动";
 sixViewController.selfUrl = @"10" ;
 //    sixViewController.view.backgroundColor = [UIColor cyanColor];
 
 ThridBaseViewController *sevenViewController = [[ThridBaseViewController alloc] init];
 sevenViewController.title = @"零食";
 sevenViewController.selfUrl = @"11" ;
 //    sevenViewController.view.backgroundColor = [UIColor blueColor];
 
 ThridBaseViewController *eightViewController = [[ThridBaseViewController alloc] init];
 eightViewController.title = @"图书";
 eightViewController.selfUrl = @"12" ;
 //    eightViewController.view.backgroundColor = [UIColor greenColor];
 
 ThridBaseViewController *ninghtViewController = [[ThridBaseViewController alloc] init];
 ninghtViewController.title = @"电器";
 ninghtViewController.selfUrl = @"13" ;
 //    ninghtViewController.view.backgroundColor = [UIColor redColor];
 
 
 }
 
 - (void) picTogeterURL {
 
 if ([self.selfUrl isEqualToString:@"0"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"2"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"4"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"7"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"8"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"10"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"11"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"12"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 
 }else if ([self.selfUrl isEqualToString:@"13"]) {
 NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
 [self downLoadDataWithURL:url];
 }
 }
 
 */
//- (void) picTogeterURL {
//
//    if ([self.selfUrl isEqualToString:@"0"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"2"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//       
//    }else if ([self.selfUrl isEqualToString:@"4"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"7"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"8"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"10"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"11"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"12"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//        
//    }else if ([self.selfUrl isEqualToString:@"13"]) {
//        NSString * url = [NSString stringWithFormat:CATEGORY_URL,self.selfUrl];
//        [self downLoadDataWithURL:url];
//    }
//}


- (void) downLoadDataWithURL:(NSString *) url {

    //初始化manager
    self.manager = [AFHTTPRequestOperationManager manager];
    //设置服务器响应的格式
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    __weak typeof (self) weakSelf = self ;
    [weakSelf.manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
//        NSLog(@"%@",responseObject);
        //把json数据转化为字典
        NSDictionary * AllDataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        //找到字典中键值是data的数据，得到的结果是个字典
        NSDictionary * dataDic = AllDataDic[@"data"];
        //找到商品数组
        NSArray * topicArray = dataDic[@"topic"];
        //加入到模型中
        for (NSDictionary * oneDic in topicArray) {
            
            MainPageModel * oneModel = [[MainPageModel alloc] initWithDictionary:oneDic error:nil];
            
            [self.dataSource addObject:oneModel];
            
        }
        [weakSelf.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];

}


- (void) createTableView {
    
    _dataSource = [NSMutableArray array];
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width,SCREEN_SIZE.height - 110 ) style:(UITableViewStylePlain)];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self ;
    self.tableView.dataSource = self ;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"MainTableViewCell" bundle:nil] forCellReuseIdentifier:@"MainTableViewCell"];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    self.tableView.showsVerticalScrollIndicator = NO ;
    
    self.tableView.tableFooterView = [[UIView alloc]init];
    
}
#pragma mark - UITableView 代理方法
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1 ;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //NSLog(@"%ld",self.dataArray.count);
    return self.dataSource.count;
    
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 200 ;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell"];
    MainPageModel * model = self.dataSource[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
    
    [cell showDataWithModel:model andIndexPath:indexPath];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
