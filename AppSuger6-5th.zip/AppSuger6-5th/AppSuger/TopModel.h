//
//  TopModel.h
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "JSONModel.h"

@interface TopModel : JSONModel

@property (nonatomic,copy)NSString <Optional>*id;
@property (nonatomic,copy)NSString <Optional>*category;
@property (nonatomic,copy)NSString <Optional>*title;

@property (nonatomic,copy)NSString <Optional>*desc;
@property (nonatomic,copy)NSString <Optional>*pic;
@property (nonatomic,copy)NSString <Optional>*width;
@property (nonatomic,copy)NSString <Optional>*height;
@property (nonatomic,copy)NSString <Optional>*likes;
@property (nonatomic,copy)NSString <Optional>*share_url;
@property (nonatomic,copy)NSString <Optional>*share_pic;
@property (nonatomic,copy)NSString <Optional>*islike;
@end
