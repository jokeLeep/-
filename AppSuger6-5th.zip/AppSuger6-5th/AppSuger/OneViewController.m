//
//  OneViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/3/5.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "OneViewController.h"

@interface OneViewController ()

@end

@implementation OneViewController


- (NSString *) reruturnUrlStr {
    
    self.selfUrl = [NSString stringWithFormat:@"http://open1.bantangapp.com/topic/list?category%@&client_id=bt_app_ios&client_secret=9c1e6634ce1c5098e056628cd66a17a5&oauth_token=5495d38a5cf1f7f460cf03aaa2e5c0a2&page=0&pagesize=20&screensize=640&update_time=0&v=1",@"0"];

    return [NSString stringWithFormat:@"http://open1.bantangapp.com/topic/list?category=%@&client_id=bt_app_ios&client_secret=9c1e6634ce1c5098e056628cd66a17a5&oauth_token=5495d38a5cf1f7f460cf03aaa2e5c0a2&page=0&pagesize=20&screensize=640&update_time=0&v=1",@"0"];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
