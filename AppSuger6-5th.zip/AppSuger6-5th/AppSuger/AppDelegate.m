//
//  AppDelegate.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "AppDelegate.h"
#import "NumberRecorder.h"
#import "AFNetworking.h"
#import "RootViewController.h"
#import "SiderViewController.h"
#import "LeftViewController.h"
#import "AppTabBarViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
//  记录软件打开次数
    [NumberRecorder recordAppLoadNum];
    //监听网络
    [self newWork];
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    LeftViewController * leftVC = [[LeftViewController alloc]init];
    AppTabBarViewController * rvc = [[AppTabBarViewController alloc]init];
    _sideViewController=[[SiderViewController alloc]init];
    _sideViewController.rootViewController = rvc ;
    _sideViewController.leftViewController = leftVC ;
    
    _sideViewController.leftViewShowWidth=200;
    _sideViewController.needSwipeShowMenu=true;//默认开启的可滑动展示

    self.window.rootViewController = _sideViewController ;
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    

    
    return YES;
}

- (void) newWork {

    AFNetworkReachabilityManager * manager = [AFNetworkReachabilityManager sharedManager];
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
       
        NSLog(@"网络状态发生变化");
        if (status == 0 ) {
            
            NSLog(@"没有联网");
        }else if (status == 1 ){
            
            NSLog(@"移动网络");
        }else if (status == 2 ) {
            
            NSLog(@"wifi 网络");
        }
        
    }];
    //开始监听
    [manager startMonitoring];
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
