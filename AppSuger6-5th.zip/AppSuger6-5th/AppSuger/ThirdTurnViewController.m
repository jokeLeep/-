//
//  ThirdTurnViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/3/1.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "ThirdTurnViewController.h"
#import "AFNetworking.h"
#import "Define.h"
#import "UIImageView+WebCache.h"

#import "MainPageModel.h"
#import "MainTableViewCell.h"

#import "MJRefresh.h"

#import "DetailViewController.h"

@interface ThirdTurnViewController ()<UITableViewDataSource,UITableViewDelegate>
//商品信息
@property (nonatomic, strong) NSMutableArray * dataSource ;

@property (nonatomic, strong) NSMutableArray * bannerImageArray ;

@property (nonatomic, strong) UITableView * tableView ;

@property (nonatomic, strong) AFHTTPRequestOperationManager * manager ;

//获取模型中的update_time属性
@property (nonatomic,copy) NSString * update_time;


@end

@implementation ThirdTurnViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor grayColor];
    [self downLoadWithURL:self.listUrl];
    
    [self createTableView];
    
    [self setRefreshData];
}

- (void) downLoadWithURL:(NSString *)url {
    //初始化manager
    self.manager = [AFHTTPRequestOperationManager manager];
    //设置服务器响应的格式
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    __weak typeof (self) weakSelf = self ;
    [weakSelf.manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //把json数据转化为字典
        NSDictionary * AllDataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        //找到字典中键值是data的数据，得到的结果是个字典
        NSDictionary * dataDic = AllDataDic[@"data"];
        //找到商品数组
        NSArray * topicArray = dataDic[@"topic"];
        //加入到模型中
        for (NSDictionary * oneDic in topicArray) {
            MainPageModel * oneModel = [[MainPageModel alloc] initWithDictionary:oneDic error:nil];
            [weakSelf.dataSource addObject:oneModel];
        }
        [weakSelf.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
    
}

- (void) createTableView {
 
    _dataSource = [NSMutableArray array];
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width,SCREEN_SIZE.height ) style:(UITableViewStylePlain)];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self ;
    self.tableView.dataSource = self ;
    [self.tableView registerNib:[UINib nibWithNibName:@"MainTableViewCell" bundle:nil] forCellReuseIdentifier:@"MainTableViewCell"];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    self.tableView.showsVerticalScrollIndicator = NO ;
    
    self.tableView.tableFooterView = [[UIView alloc]init];
    
}
#pragma mark - UITableView 代理方法
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {

    return 1 ;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //NSLog(@"%ld",self.dataArray.count);
    return self.dataSource.count;
    
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    return 200 ;
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell"];
    
    MainPageModel * model = self.dataSource[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
    [cell showDataWithModel:model andIndexPath:indexPath];
    
    return cell;
    
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

//    [self touchNavigationBarBack];
   MainPageModel *model  =  self.dataSource[indexPath.row];
//    NSString * cellID = dic[@"id"];
    NSLog(@"%@", [NSString stringWithFormat:DETAIL_URL,model.id]);
    
    
    DetailViewController * devc = [[DetailViewController alloc]init];
    devc.mainCell = model.id ;
    //这一句代码是为了解决列表界面的frame的问题
    devc.type = @"mainPage";
    //为以后的收藏 做准备
    devc.model = model ;
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    //当进入到下一个界面的时候 隐藏地步的toolbar
//    devc .hidesBottomBarWhenPushed = YES ;
    [self.navigationController pushViewController:devc animated:YES];
    
}

#pragma mark - 刷新数据的方法
- (void) setRefreshData {
    //添加下拉刷新功能
    [self.tableView addHeaderWithTarget:self action:@selector(headerRefreshing) dateKey:@"table"];
    //设置头部提示
    self.tableView.headerPullToRefreshText = @"下拉可以刷新";
    self.tableView.headerReleaseToRefreshText = @"松开即可刷新";
    self.tableView.headerRefreshingText = @"正在下载中";
    //添加上拉刷新
    [self.tableView addFooterWithTarget:self action:@selector(footerRefreshing)];
    //设置底部提示
    self.tableView.footerPullToRefreshText = @"继续向上拉可以刷新";
    self.tableView.footerReleaseToRefreshText = @"松开即可刷新";
    self.tableView.footerRefreshingText = @"正在加载中";}


// - 下拉 -
- (void)headerRefreshing {
    [self performSelector:@selector(refreshData) withObject:nil afterDelay:2.0];
}
- (void)refreshData {
    //在此处进行网络数据的加载
    //NSLog(@"更新数据");
    //插入的数据
    //MainModel * oneModel = self.dataArray.lastObject;
    [self.dataSource removeAllObjects];
    self.update_time = 0;
    
    [self downLoadWithURL:self.listUrl];
    // 动画效果
    CATransition * transaction = [CATransition animation];
    transaction.type = @"rippleEffect";
    transaction.duration = 1;
    [self.tableView.layer addAnimation:transaction forKey:nil];
    //刷新界面
    [self.tableView reloadData];
    //结束刷新
    [self.tableView headerEndRefreshing];
}
// - 上拉 -
- (void)footerRefreshing {
    [self performSelector:@selector(loadMoreData) withObject:nil afterDelay:2.0];
}
- (void)loadMoreData {
    //此处加载新的数据
    ///////////////////
//    MainPageModel * oneModel = self.dataSource.lastObject;
//    self.update_time = self.update_time + 1;
    static int  time = 1 ;
    time ++ ;
    NSString * url = [NSString stringWithFormat:@"http://open1.bantangapp.com/topic/list?category=%@&client_id=bt_app_ios&client_secret=9c1e6634ce1c5098e056628cd66a17a5&oauth_token=5495d38a5cf1f7f460cf03aaa2e5c0a2&page=%d&pagesize=20&screensize=640&update_time=0&v=1",self.type,time];
    
    [self downLoadWithURL:url];
    // 动画效果
    CATransition * transaction = [CATransition animation];
    transaction.type = @"rippleEffect";
    transaction.duration = 1;
    [self.tableView.layer addAnimation:transaction forKey:nil];
    //刷新界面
    [self.tableView reloadData];
    //结束刷新
    [self.tableView footerEndRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
