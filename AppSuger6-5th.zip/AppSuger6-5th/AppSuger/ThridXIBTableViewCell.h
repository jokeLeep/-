//
//  ThridXIBTableViewCell.h
//  AppSuger
//
//  Created by qianfeng on 16/3/3.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThridXIBTableViewCell : UITableViewCell

@end
