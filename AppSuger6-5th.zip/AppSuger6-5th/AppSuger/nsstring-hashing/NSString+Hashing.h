

#import <Foundation/Foundation.h>
@interface NSString (NSString_Hashing)

- (NSString *)MD5Hash;

@end
