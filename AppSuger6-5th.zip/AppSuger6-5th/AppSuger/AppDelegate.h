//
//  AppDelegate.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SiderViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) SiderViewController * sideViewController ;


@end

