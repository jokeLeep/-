//
//  AppTabelViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "BaseViewController.h"

@interface AppTabelViewController : BaseViewController

@end
