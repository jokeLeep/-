//
//  ContentInMainViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "MainPageViewController.h"
#import "AFNetworking.h"


@protocol TopViewProtocol <NSObject>

- (void) setTopViewWithNewsArray:(NSMutableArray *)array;

@end

@interface ContentInMainViewController : MainPageViewController

//滚动图片的数组
@property (nonatomic, strong) NSMutableArray * bannerImagesArray;

//协议
@property (assign) id<TopViewProtocol>delegate ;

//第一次下载数据
- (void) fristDownLoadDataSource ;
//开始下载数据
- (void) downLoadWithURL:(NSString *)updataTime;

@end
