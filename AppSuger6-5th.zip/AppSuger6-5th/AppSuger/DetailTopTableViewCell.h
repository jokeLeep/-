//
//  DetailTopTableViewCell.h
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TopModel.h"

@interface DetailTopTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *buttonImageView;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *deslabel;

-(void) congfigDataWithTopModel :(TopModel *)model ;

@end
