//
//  MainPageModel.h
//  AppSuger
//
//  Created by qianfeng on 16/2/26.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "JSONModel.h"

@interface MainPageModel : JSONModel

/*
 id = 2280;
 islike = 0;
 likes = 5645;
 pic = "http://bt.img.17gwx.com/topic/0/22/cFNWZA/620x280";
 tags = "\U8fd0\U52a8\U88e4,\U8fd0\U52a8\U978b,\U8dd1\U978b,\U5065\U8eab,\U8fd0\U52a8\U4e0a\U8863";
 title = "\U5c0f\U674e\U4e0d\U54ed\Uff01\U5965\U65af\U5361\U5df2\U5230\U624b\Uff0c\U8089\U54b1\U6162\U6162\U51cf";
 type = 0;
 "update_time" = 1456747201;
 */

@property (nonatomic,copy)NSString <Optional>*id;
@property (nonatomic,copy)NSString <Optional>*islike;
@property (nonatomic,copy)NSString <Optional>*title;
@property (nonatomic,copy)NSString <Optional>*pic;
@property (nonatomic,copy)NSString <Optional>*likes;
@property (nonatomic,copy)NSString <Optional>*update_time;


@property (nonatomic,copy)NSString <Optional>*photo;
@property (nonatomic,copy)NSString <Optional>*number;
@property (nonatomic,copy)NSString <Optional>*desc;
@property (nonatomic,copy)NSString <Optional>*price;
@property (nonatomic,copy)NSString <Optional>*url;
@property (nonatomic,copy)NSString <Optional>*extend;
@property (nonatomic,copy)NSString <Optional>*type;

@end
