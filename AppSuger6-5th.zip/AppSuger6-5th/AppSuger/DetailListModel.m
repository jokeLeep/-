//
//  DetailListModel.m
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "DetailListModel.h"

@implementation DetailListModel


@end
