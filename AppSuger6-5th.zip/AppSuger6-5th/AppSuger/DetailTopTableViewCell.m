//
//  DetailTopTableViewCell.m
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "DetailTopTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation DetailTopTableViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (void) congfigDataWithTopModel:(TopModel *)model {
    
    //标题
    self.titleLabel.text = model.title ;
    //商品的描述
    self.deslabel.text = model.desc ;
    [self.titleLabel setFont:[UIFont fontWithName:@"American Typewriter" size:15]];
    [self.deslabel setFont:[UIFont fontWithName:@"American Typewriter" size:13]];
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
