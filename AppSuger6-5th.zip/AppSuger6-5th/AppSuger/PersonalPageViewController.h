//
//  PersonalPageViewController.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "MainPageViewController.h"
#import <UIKit/UIKit.h>
@interface PersonalPageViewController : MainPageViewController
@property (nonatomic,strong) UITableView * tableView;

@end
