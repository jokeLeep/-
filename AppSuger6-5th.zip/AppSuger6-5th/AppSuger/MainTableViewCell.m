//
//  MainTableViewCell.m
//  AppSuger
//
//  Created by qianfeng on 16/2/26.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "MainTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation MainTableViewCell

- (void)awakeFromNib {
    // Initialization code
    //设置主界面表格的圆角
    self.picImage.layer.masksToBounds = YES;
    self.picImage.layer.cornerRadius = 8 ;
    
    self.heartImage.layer.masksToBounds = YES;
    self.heartImage.layer.cornerRadius = 5 ;
    
    self.buttonImage.layer.masksToBounds = YES;
    self.buttonImage.layer.cornerRadius = 8 ;
    
    
}
- (void) showDataWithModel:(MainPageModel *) mainModel andIndexPath:(NSIndexPath *)indexPath {
    
    //利用第三方库获取图片
    [self.picImage sd_setImageWithURL:[NSURL URLWithString:mainModel.pic] placeholderImage:[UIImage imageNamed:@"placehoder"]];
    //标题
    self.titleLabel.text = mainModel.title;
    //喜欢人数
    self.loveNumLabel.text = mainModel.likes ;
    [self.titleLabel setFont:[UIFont fontWithName:@"American Typewriter" size:15]];
    [self.loveNumLabel setFont:[UIFont fontWithName:@"American Typewriter" size:10]];
    }

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
