//
//  RootViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//
//这个界面 可以写广告 效果还有 各种酷炫开启动画
#import "RootViewController.h"
#import "NumberRecorder.h"
#import "AppTabBarViewController.h"
#import "AppDelegate.h"



@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.view.backgroundColor = [UIColor whiteColor];
    
        AppTabBarViewController * appVC = [[AppTabBarViewController alloc]init];
        [self.navigationController pushViewController:appVC animated:YES];
      
//    AppTabBarViewController * appVC = [[AppTabBarViewController alloc]init];
//    [self.navigationController pushViewController:appVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
