//
//  DetailUrl.h
//  AppSuger
//
//  Created by qianfeng on 16/2/29.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#ifndef DetailUrl_h
#define DetailUrl_h


#endif /* DetailUrl_h */
