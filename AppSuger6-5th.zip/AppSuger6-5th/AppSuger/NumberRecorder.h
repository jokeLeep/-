//
//  NumberRecorder.h
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NumberRecorder : NSObject
/**
 *  记录应用打开的次数
 */
+ (void) recordAppLoadNum ;
/**
 *  是否第一次打开软件
 *
 *  @return YES 或 NO
 */
+ (BOOL) isFirstLoadApp ;

@end
