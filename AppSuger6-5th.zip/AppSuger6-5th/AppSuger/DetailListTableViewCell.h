//
//  DetailListTableViewCell.h
//  AppSuger
//
//  Created by qianfeng on 16/2/27.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailListModel.h"

@interface DetailListTableViewCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UIImageView *numImage;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIImageView *PicImage;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;

- (void) configDataWithModel:(DetailListModel *)model indexPath:(NSIndexPath *)indexPath ;

@end
