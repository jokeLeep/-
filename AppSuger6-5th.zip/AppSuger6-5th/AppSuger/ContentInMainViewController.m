//
//  ContentInMainViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "ContentInMainViewController.h"
#import "Define.h"
#import "MJRefresh.h"
#import "MainTableViewCell.h"
#import "MainPageModel.h"

//滚动视图
#import "AdScrollView.h"
#import "AdDataModel.h"
//缓存
#import "CacheFunc.h"

#import "DetailViewController.h"

@interface ContentInMainViewController ()<UITableViewDataSource,UITableViewDelegate>
//用来存储商品数据的数组
@property (nonatomic, strong) NSMutableArray * dataArray ;
//用来存储横幅数据的数组
@property (nonatomic, strong) NSMutableArray * bannerArray ;

//下面的滚动视图
@property (nonatomic, strong) UITableView * tableView ;
//利用第三方类来异步下载网络数据
@property (nonatomic, strong) AFHTTPRequestOperationManager * manager ;
//请求网络数据的接口
@property (nonatomic, strong) NSString * requestURL ;
//获取时间updataTime
@property (nonatomic, strong) NSString * updateTime ;

@end

@implementation ContentInMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //子类重写父类的方法
    [self createViews:@"糖糖"];
    //创建下面的滚动视图
    [self createTableView];
    // 滚动的navigationbar
    [self followRollingScrollerView:self.tableView];
    //初始化manager
    self.manager = [AFHTTPRequestOperationManager manager];
    //设置服务器响应格式
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    //下载数据
    [self fristDownLoadDataSource];
    
    //刷新数据
    [self setRefreshData];
    
}
#pragma mark - 下载数据的方法
- (void)fristDownLoadDataSource {

    self.updateTime = 0 ;
    [self downLoadWithURL:self.updateTime];
}
static int i = 0 ;
- (void) downLoadWithURL:(NSString *)updataTime {
    __weak typeof (self) weakSelf = self ;
    NSString * url = [NSString stringWithFormat:MAIN_URL,self.updateTime];
    //利用第三方库AFNetWorking 下载网络数据 GET 方法
    [weakSelf.manager GET:url parameters:nil
                  success:^(AFHTTPRequestOperation *operation, id responseObject) {
                      
                      //访问数据成功 把数据保存
//                      [CacheFunc saveDataToCacheWith:MAIN_CACHE andUpdateTime:self.updateTime.integerValue andData:responseObject];
                      //把json数据转化为字典
                      NSDictionary * allDataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
                      //找到字典中的键值是data 的数据 得到的结果是一个字典
                      NSDictionary * dataDic = allDataDic[@"data"];
                      //找到商品数组
                      NSArray * topicArray = dataDic[@"topic"];
                      if (topicArray.count == 0 ){
                          return ;
                      }
                      //下拉滚动 视图数据
                      for (NSDictionary * topicDic in topicArray) {
                          MainPageModel * topModel = [[MainPageModel alloc]initWithDictionary:topicDic error:nil];
                          [weakSelf.dataArray addObject:topModel];
//                          NSLog(@"topModel:%@",topModel);
                      }
                      //横幅视图数据
                      NSArray * bannerArray = dataDic[@"banner"];
                      //加入到模型中
                      for (NSDictionary * bannerDic in bannerArray) {
                          MainPageModel * bannerModel = [[MainPageModel alloc] initWithDictionary:bannerDic error:nil];
//                          NSLog(@"banner %@",bannerModel);
                          [weakSelf.bannerImagesArray addObject:bannerModel.photo];
                      }
                      //创建顶部的视图
                      if (i == 0) {
                         [weakSelf createScrollView];
                          i++;
                      }
                      //代理方法
                      if ([weakSelf.delegate respondsToSelector:@selector(setTopNewsWithNewsArray:)]){
                          [weakSelf setTopNewsWithNewsArray:self.bannerImagesArray];
                      }
                      [weakSelf.tableView reloadData];
                    
                  } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
              
                  }];
}

#pragma mark - 创建表格视图 以及表格视图的代理方法
- (void) createTableView {
    
    self.dataArray = [[NSMutableArray alloc] init];
    self.bannerImagesArray = [[NSMutableArray alloc]init];
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height - 64 ) style:(UITableViewStylePlain)];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self ;
    self.tableView.dataSource = self ;
    [self.tableView registerNib:[UINib nibWithNibName:@"MainTableViewCell" bundle:nil] forCellReuseIdentifier:@"MainTableViewCell"];
    //分割状态 没有状态
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    //显示竖直指示 设置没有 cell 的cell 分割线隐藏
    self.tableView.showsVerticalScrollIndicator = NO ;
    self.tableView.tableFooterView = [[UIView alloc] init];
    
    
}

#pragma mark - 头部滚动视图
- (void) createScrollView {
    AdScrollView * scrollView = [[AdScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, 200)];
    AdDataModel * dataModel = [AdDataModel adDataModelWithImageNameAndAdTitleArray];
    dataModel.imageNameArray = self.bannerImagesArray ;
    scrollView.imageNameArray = dataModel.imageNameArray ;
    scrollView.PageControlShowStyle = UIPageControlShowStyleRight ;
    // 设置指示器的颜色
    scrollView.pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    [scrollView setAdTitleArray:dataModel.adTitleArray withShowStyle:(AdTitleShowStyleLeft)];
//    设置当前指示器的颜色
    scrollView.pageControl.currentPageIndicatorTintColor = [UIColor grayColor];
    self.tableView.tableHeaderView = scrollView;

}
#pragma mark - 表格视图的代理方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 ;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count ;
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 200 ;
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
    MainTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell" forIndexPath:indexPath];
    //设置点击的时候不显示选中的灰色背景颜色
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    MainPageModel * model = self.dataArray[indexPath.row];
    [cell showDataWithModel:model andIndexPath:indexPath];
    return cell ;
}
//点击了表格的某一行
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //点击显示navigationbar 解决bug
    [self touchNavigationBarBack];
    MainPageModel * model =  self.dataArray[indexPath.row];
    DetailViewController * devc = [[DetailViewController alloc]init];
    devc.mainCell = model.id ;
    //这一句代码是为了解决列表界面的frame的问题
    devc.type = @"mainPage";
    //为以后的收藏 做准备
    devc.model = model ;
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    //当进入到下一个界面的时候 隐藏地步的toolbar
    devc .hidesBottomBarWhenPushed = YES ;
    [self.navigationController pushViewController:devc animated:YES];
}

- (void) setTopNewsWithNewsArray:(NSMutableArray *)array {
}

#pragma mark - 刷新数据的方法 - 
- (void) setRefreshData {

    //添加下拉刷新功能
   [self.tableView addHeaderWithTarget:self action:@selector(headerRefreshing) dateKey:@"table"];
    self.tableView.headerPullToRefreshText = @"下拉可以刷新";
    self.tableView.headerReleaseToRefreshText = @"松开即可刷新";
    self.tableView.headerRefreshingText = @"正在加载中...";
    //添加上拉刷新
    [self.tableView addFooterWithTarget:self action:@selector(footerRefreshing)];
    
    //设置底部提示
    self.tableView.footerPullToRefreshText = @"继续向上拉可以刷新";
    self.tableView.footerReleaseToRefreshText = @"松开即可刷新";
    self.tableView.footerRefreshingText = @"正在加载中";
}
// 下拉
- (void) headerRefreshing {

    [self performSelector:@selector(refreshData) withObject:nil afterDelay:1.0];
}
- (void) refreshData {

    //插入数据
    [self.dataArray removeAllObjects];
    [self.bannerImagesArray removeAllObjects];
    self.updateTime = 0 ;
    [self downLoadWithURL:MAIN_URL];
    CATransition * transition = [CATransition animation];
    transition.type = @"rippleEffect";
    transition.duration = 1 ;
    [self.tableView.layer addAnimation:transition forKey:nil];
    //刷新界面
    [self.tableView reloadData];
    //结束刷新
    [self.tableView headerEndRefreshing];
}
//上拉
- (void) footerRefreshing {
    [self performSelector:@selector(loadMoreData) withObject:nil afterDelay:1.0];
}
- (void) loadMoreData {

    MainPageModel * mainModel = self.dataArray.lastObject ;
    self.updateTime = mainModel.update_time ;
    [self downLoadWithURL:MAIN_URL];
    //动画效果
    CATransition * transaction = [CATransition animation] ;
    transaction.type = @"rippleEffect" ;
    transaction.duration = 1 ;
    [self.tableView.layer addAnimation:transaction forKey:nil];
    // 刷新界面
    [self.tableView reloadData];
    // 结束刷新
    [self.tableView footerEndRefreshing];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
