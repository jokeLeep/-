//
//  ThirdTableView.h
//  AppSuger
//
//  Created by qianfeng on 16/3/4.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Define.h"
#import "ThridBaseViewController.h"


@interface ThirdTableView : UITableView
//<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView ;
@property (nonatomic, copy) NSString * selfUrl ;

- (NSString *) reruturnUrlStr;

@end
