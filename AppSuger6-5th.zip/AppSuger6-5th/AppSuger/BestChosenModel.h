//
//  BestChosenModel.h
//  AppSuger
//
//  Created by qianfeng on 16/2/26.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "JSONModel.h"

@interface BestChosenModel : JSONModel

@end
