//
//  ScrollingHideNavBarViewController.m
//  AppSuger
//
//  Created by qianfeng on 16/2/25.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import "ScrollingHideNavBarViewController.h"
#define SeNavBar self.navigationController.navigationBar
#define NavBarFrame SeNavBar.frame
@interface ScrollingHideNavBarViewController ()<UIGestureRecognizerDelegate>

@property (strong, nonatomic) UIPanGestureRecognizer * panGesture ;
@property (strong, nonatomic) UITapGestureRecognizer * tapGesture ;
@property (strong, nonatomic) UIView * overLay ;

@end

@implementation ScrollingHideNavBarViewController

//- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
//
//    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
//    if (self) {
//    }
//   return self ;
//}


//设置跟随滚动的滑动视图
- (void) followRollingScrollerView:(UIView *)scrollView {

    self.scrollView = scrollView ;
    self.panGesture = [[UIPanGestureRecognizer alloc]init];
    self.panGesture.delegate =self ;
    self.panGesture.minimumNumberOfTouches = 1 ;
    
    [self.panGesture addTarget:self action:@selector(handlePanGesture:)];
    [self.scrollView addGestureRecognizer:self.panGesture];
    
    self.overLay = [[UIView alloc] initWithFrame:SeNavBar.bounds];
    self.overLay.alpha = 0 ;
    self.overLay.backgroundColor = SeNavBar.barTintColor ;
    
    [SeNavBar addSubview:self.overLay];
    [SeNavBar bringSubviewToFront:self.overLay];
}

- (void) touchNavigationBarBack {

    if (self.isHidden) {
        self.overLay.alpha = 0 ;
        CGRect navBarFrame = NavBarFrame ;
        CGRect scrollViewFrame = self.scrollView.frame ;
        
        navBarFrame.origin.y = 20 ;
        scrollViewFrame.origin.y += 44 ;
        scrollViewFrame.size.height -= 44 ;
        
        [UIView animateWithDuration:0.2 animations:^{
            NavBarFrame = navBarFrame ;
            self.scrollView.frame = scrollViewFrame ;
        }];
        self.isHidden = NO ;
    }
}

#pragma mark - 兼容其他手势
- (BOOL) gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {

    return YES;
}

#pragma mark - 手势调用会函数
-(void)handlePanGesture:(UIPanGestureRecognizer *)panGesture{
    
    CGPoint translation = [panGesture translationInView:[self.scrollView superview]];
    
    if (translation.y >= 5) {
        if (self.isHidden) {
        
            self.overLay.alpha = 0 ;
            CGRect navBarFrame = NavBarFrame ;
            CGRect scrollViewFrame = self.scrollView.frame ;
            
            navBarFrame.origin.y = 20 ;
            scrollViewFrame.origin.y += 44 ;
            scrollViewFrame.size.height -= 44 ;
            
            [UIView animateWithDuration:0.2 animations:^{
                NavBarFrame = navBarFrame ;
                self.scrollView.frame = scrollViewFrame ;
            }];
            self.isHidden = NO ;
        }
    }
    //隐藏
    if (translation.y <= -20) {
        if (!self.isHidden) {
        
            CGRect navBarframe = NavBarFrame ;
            CGRect scrollViewframe = self.scrollView.frame ;
            navBarframe.origin.y = - 24 ;
            scrollViewframe.origin.y -= 44 ;
            scrollViewframe.size.height += 44 ;
            
            [UIView animateWithDuration:0.2 animations:^{
                NavBarFrame = navBarframe ;
                self.scrollView.frame = scrollViewframe ;
            }completion:^(BOOL finished) {
                self.overLay.alpha = 1 ;
            }];
            self.isHidden = YES ;
        }
    }
}

- (void) viewDidAppear:(BOOL)animated {

    [SeNavBar bringSubviewToFront:self.overLay];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
