//
//  CacheFunc.h
//  AppSuger
//
//  Created by qianfeng on 16/2/26.
//  Copyright © 2016年 李沛衡. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CacheFunc : NSObject

@property float size ;

+ (void)saveDataToCacheWith:(NSString *)cacheName andUpdateTime:(NSInteger)updateTime andData:(NSData *)data;
+ (NSData *)getDataFromCacheWith:(NSString *)cacheName andUpdateTime:(NSInteger)updateTime;
//计算文件夹下得文件的大小
- (float)fileSizeForDir:(NSString *)path;

@end
